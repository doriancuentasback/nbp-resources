/**
 * @returns {JSON}
 */
var JSON = {
}
/**
 * @syntax stringify(value[,replacer[,space]])
 * @param {Object} value
 * @returns {String}
 * @static
 */
JSON.stringify = function(value) {};

/**
 * @syntax parse(string)
 * @param {String} string
 * @returns {Array|Object}
 * @static
 */
JSON.parse = function(string) {};

/**
 * Represents the JSON prototype object.
 * @syntax JSON.prototype
 * @static
 */
JSON.prototype;

