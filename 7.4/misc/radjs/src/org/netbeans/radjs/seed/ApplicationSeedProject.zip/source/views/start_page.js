RAD.view("view.start_page", RAD.Blanks.View.extend({
    url: 'source/views/start_page.html'
}));