RAD.view("view.inner_third_widget", RAD.Blanks.View.extend({
    className: " rad-header",
    url: 'source/views/inner/third_widget/third_widget.html'
}));