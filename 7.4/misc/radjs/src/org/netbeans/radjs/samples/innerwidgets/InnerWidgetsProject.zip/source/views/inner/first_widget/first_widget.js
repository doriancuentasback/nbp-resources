RAD.view("view.inner_first_widget", RAD.Blanks.ScrollableView.extend({
    url: 'source/views/inner/first_widget/first_widget.html'
}));